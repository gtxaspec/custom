#!/sbin/sh

#when you format /system, the intel hypervisor detects this, and sets `formatesystem!` on 00100c00 of mmcblk0p13.  Upon successful installation of a ROM, 
#without clearing this, the recovery will throw an error, and force you to reinstall. We replace the bits to avoid this.
#this also has the benefit of avoiding a force flash of p13 with an image from a 1024 or 800 unit, as the display config is also stored in this partition.
#now all units can use this rom.

printf '\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\x00' | busybox dd of=/dev/block/mmcblk0p13 bs=1 seek=1051648 count=16 conv=notrunc 
printf '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00' | busybox dd of=/dev/block/mmcblk0p13 bs=1 seek=1051664 count=16 conv=notrunc 

#clear BCB of reboot marker so system reboots to system, not boot loop into recovery

printf '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00' | busybox dd of=/dev/block/mmcblk0p17 bs=1 seek=16384 count=16 conv=notrunc
printf '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00' | busybox dd of=/dev/block/mmcblk0p17 bs=1 seek=16448 count=16 conv=notrunc
printf '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00' | busybox dd of=/dev/block/mmcblk0p17 bs=1 seek=16464 count=16 conv=notrunc
printf '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00' | busybox dd of=/dev/block/mmcblk0p17 bs=1 seek=16480 count=16 conv=notrunc
printf '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00' | busybox dd of=/dev/block/mmcblk0p17 bs=1 seek=16496 count=16 conv=notrunc


##delete upgrade marker

rm -f /data/.gtx_upgrade

#!/sbin/sh

#make the LED's on the unit flash in a rainbow of FURY during installation.

 i=0
  marks='a b c d e f g h'
  while true; do
    if [ $# -lt 4 ]; then
      set -- "$@" $marks
    fi
    shift $(( (i+1) % $# ))
    #printf '%s\r' "$1"
    echo -n "$1" > /sys/fytver/colorled
    sleep 0.1
  done


#!/sbin/sh

##Extract TWRP to root
/sbin/busybox tar -xvf /TEMP-TWRP

##Delete /cache/recovery/command to prevent loop
/sbin/busybox rm -f /cache/recovery/command

##Find install media mount point
mount=`/sbin/busybox df -h | /sbin/busybox grep mnt | /sbin/busybox sed -r 's_^.*/([^/]*)/*$_\1_g'`



##Export mount points, if debug.
#/sbin/busybox df -h > /cache/df_output

##Replace mount in openrecoveryscript to match installation media ( sd, sdio, usb_storage )
if [ $mount == "usb_storage" ]; then
echo "usb_storage" > /cache/result
##Extract openrecoveryscript to cache for TWRP auto-loading
/sbin/busybox cp /mnt/usb_storage/openrecoveryscript /cache/recovery/openrecoveryscript
##This is the default
elif [ $mount == "external_sd" ]; then
echo "external_sd" > /cache/result
##Extract openrecoveryscript to cache for TWRP auto-loading
/sbin/busybox cp /mnt/external_sd/openrecoveryscript /cache/recovery/openrecoveryscript
/sbin/busybox sed -e 's/usb_storage/external_sd/g' /cache/recovery/openrecoveryscript
elif [ $mount == "external_sdio" ]; then
echo "external_sdio" > /cache/result
##Extract openrecoveryscript to cache for TWRP auto-loading
/sbin/busybox cp /mnt/external_sdio/openrecoveryscript /cache/recovery/openrecoveryscript
/sbin/busybox sed -e 's/usb_storage/external_sdio/g' /cache/recovery/openrecoveryscript

fi

##Bring up ETH0 on usb0 for adb
/sbin/ifconfig eth0 192.168.65.100

##Enable ADB
setprop service.adb.root 1
setprop service.adb.tcp.port 5555

##Restart ADB
stop adbd
start adbd

#set TWRP properties
setprop recovery.twrp.status enabled

##set framebuffer "fb0" mode
echo U:1024x600p-65 > /sys/devices/fb.210/graphics/fb0/mode

##kill SYU recoery, re-set framebuffer mode, and launch TWRP recovery
/sbin/busybox killall -9 recovery && echo U:1024x600p-65 > /sys/devices/fb.210/graphics/fb0/mode && /sbin/recovery &


exit 1

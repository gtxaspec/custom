#!/sbin/sh

#i="/sbin/busybox ps | grep /cache/color.sh | head -1 | cut -c1-5"; pkill -9 ${i}

pkill -f color.sh 

 i=0
  marks='d h'
  while true; do
    if [ $# -lt 4 ]; then
      set -- "$@" $marks
    fi
    shift $(( (i+1) % $# ))
    #printf '%s\r' "$1"
    echo -n "$1" > /sys/fytver/colorled
    sleep 0.1
  done



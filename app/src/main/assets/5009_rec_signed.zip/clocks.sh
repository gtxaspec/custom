#!/sbin/sh

maxfreq=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq)

echo performance | tee /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor

max_clock() {
if [ "$maxfreq" == "1200000" ];
then

        echo 1200000 | tee /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq;
        echo 1200000 | tee /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq;
elif [ "$maxfreq" == "1040000" ];
then
        echo 1040000 | tee /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq;
        echo 1040000 | tee /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq;
fi

if [ `cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_cur_freq` == "1040000" ] || [ `cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_cur_freq` == "1200000" ]; then
        echo "clock ok"
        else
        sleep 0.2
        max_clock
fi
}

max_clock

